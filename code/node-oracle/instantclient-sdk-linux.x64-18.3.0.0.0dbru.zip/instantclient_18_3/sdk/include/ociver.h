#ifndef OCIVER_ORACLE
#define OCIVER_ORACLE

#define OCI_MAJOR_VERSION 18             /* Feature release version */
#define OCI_MINOR_VERSION 3              /* Release update version */

#endif
